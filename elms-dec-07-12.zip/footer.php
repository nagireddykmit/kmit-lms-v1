<nav class="navbar navbar-inverse navbar-fixed-bottom">
 <div class="container-fluid ">
    <div class="navbar-footer">
		 <div class="copyright" style="color:white;letter-spacing:2px">
        &copy; Copyright <strong>KMIT</strong>. All Rights Reserved
      </div>
		<div class="credits" style="color:white;letter-spacing:2px">
        Designed by <a href="https://kmit.in/"target="_blank">KMIT</a>
      </div>
	</div>
</div>